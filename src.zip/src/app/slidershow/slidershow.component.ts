import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-slidershow',
  templateUrl: './slidershow.component.html',
  styleUrls: ['./slidershow.component.css']
})
export class SlidershowComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
